<?php

$config = array(
	'tags' => array(
		'form' => 'start form',
		'formend' => 'finish form',
		'hiddenblock' => '<div class="hidden">%s</div>'
	)
);